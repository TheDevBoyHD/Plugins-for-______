<?php

namespace discord;

use pocketmine\command\{Command,CommandSender,ConsoleCommandSender};
use pocketmine\{Server,Player};
use pocketmine\plugin\PluginBase;
use pocketmine\event\Listener;
use pocketmine\utils\TextFormat as C;
use pocketmine\utils\Config;
class Main extends PluginBase implements Listener{
       public $cfg;
   public function onEnable() {
       @mkdir($this->getDataFolder());		
        $this->cfg = new Config($this->getDataFolder() . "discord.yml", Config::YAML,[
             "message-1" => "§7-----§f[§eDiscord§f]§7-----",
             "message-2" => "Join discord:",
             "message-3" => "link"]);
        $this->getServer()->getPluginManager()->registerEvents($this,$this);
        $this->getLogger()->info(C::GREEN . "Online");
    }

    public function onDisable() {
        $this->getLogger()->info(C::RED . "Offline");
    }

    public function onCommand(CommandSender $s,Command $cmd,string $label,array $args):bool{
    switch($cmd->getName()){
      case "discord":
     $s->sendMessage(C::YELLOW.$this->cfg->get("message-1")."\n".$this->cfg->get("message-2")."\n".$this->cfg->get("message-3"));
      break;  
    }
    return true;
    }

}
